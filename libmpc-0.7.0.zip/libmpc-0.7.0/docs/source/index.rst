.. libmpc++ documentation master file, created by
   sphinx-quickstart on Mon Sep 20 12:33:08 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

libmpc++'s homepage
===================

.. toctree::
   :maxdepth: 2
   :caption: Table of contents:

   introduction/introduction
   manual/manual
   api/api
   api/reference
   cite/cite