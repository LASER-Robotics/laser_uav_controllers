********************
Developer references
********************

For developers, click here_ to get to the full library references

.. _here: ../doxygen/index.html